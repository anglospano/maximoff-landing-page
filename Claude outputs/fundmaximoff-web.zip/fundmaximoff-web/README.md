# fundmaximoff.org

Sitio estático (HTML + Tailwind compilado). No requiere servidor de aplicaciones.

## Estructura
```
index.html                         -> Inicio
transparencia/rte2026/index.html   -> Página del registro web RTE (fundmaximoff.org/transparencia/rte2026/)
transparencia/rte2026/docs/        -> PDF descargables (ver LEEME.txt)
assets/css/styles.css              -> CSS compilado (no editar a mano)
assets/img/                        -> logo y favicon
src/input.css                      -> estilos fuente: componentes .card, .btn-primary, .rte-row, etc.
tailwind.config.js                 -> colores y fuentes de la línea gráfica (Stitch "Vibrant Pulse")
```

## Editar y compilar
```
npm install
npm run dev     # recompila el CSS al guardar
npm run build   # CSS final minificado
```
Tailwind solo incluye en el CSS las clases que encuentra en los .html, por eso hay que compilar después de cambiar clases.

## Pendientes antes de publicar (buscar "AJUSTAR" en los .html)
- Texto de la actividad meritoria: igualarlo al objeto social y al formato 5245.
- Fecha de publicación en la página RTE.
- Subir los 6 PDF a transparencia/rte2026/docs/.

## Despliegue
Sube todo menos `node_modules/`, `src/`, `package*.json` y `tailwind.config.js` a la raíz del hosting de fundmaximoff.org.
La URL del RTE queda: https://fundmaximoff.org/transparencia/rte2026/
